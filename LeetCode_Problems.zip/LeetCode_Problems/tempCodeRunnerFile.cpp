std::cout << max.first << " " << max.second;
        std::cout << min.first << " " << min.second;